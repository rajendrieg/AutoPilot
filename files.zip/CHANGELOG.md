# Changelog

All notable changes to AutoPilot are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [3.0.0] — 2026-09-02

### Added — Complete Enterprise Platform (34 tools)

**Module 5 — Scale & Growth (5 new tools)**
- `scalability_engine` — Assess scalability and calculate resource multipliers at each growth stage
- `capacity_planner` — Plan staff, infrastructure, and budget requirements as you scale
- `growth_modeller` — Model conservative, moderate, and aggressive growth scenarios
- `unit_economics_calculator` — Calculate how margins and unit economics change at scale
- `market_sizing_tool` — Estimate TAM, SAM, and realistic revenue potential for any market

**Module 6 — Communication & Execution (6 new tools)**
- `goal_communicator` — Generate calibrated progress emails and alerts based on goal performance
- `stakeholder_reporter` — Auto-generate reports tailored to board, management, team, or funders
- `intervention_scheduler` — Create structured intervention plans with calendar events and owners
- `milestone_celebrator` — Generate congratulatory communications when targets are achieved
- `escalation_manager` — Escalate critical issues to senior stakeholders automatically
- `goal_dashboard_live` — Generate live goal tracking dashboards with automated Power Automate refresh

### Changed
- Version bumped to 3.0.0
- Server name updated to reflect enterprise platform scope
- `validate_schema` expanded to detect Budget, Project, HR, Sales, and Inventory file schemas

---

## [2.1.0] — 2026-09-02

### Added

**Module 7 — Dashboard Generation**
- `generate_dashboard` — Generate complete Power BI, Excel, and SharePoint dashboard specifications from any data source. No manual dashboard building required.

### Changed
- Version bumped to 2.1.0
- `validate_schema` expanded with additional schema patterns

---

## [2.0.0] — 2026-09-02

### Added — Full Automation and Intelligence Platform (6 tools → 9 tools)

**Module 1 — Automation (expanded)**
- `audit_flow` — Audit Power Automate flows for errors and best practice violations
- `generate_flow` — Generate complete flows from plain English descriptions
- `debug_flow` — Diagnose failing flows with root cause analysis
- `optimize_flow` — Identify and fix performance issues in existing flows
- `suggest_automation` — Recommend the best automation approach for any manual process

**Module 2 — Visualisation**
- `generate_graph` — Recommend optimal chart types with build instructions
- `generate_analytics` — Return statistical insights and anomalies from any dataset

### Changed
- Removed hardcoded references to specific use cases from tool descriptions
- Generalised `validate_schema` to support any data source type
- Version bumped to 2.0.0
- Platform repositioned as a general-purpose automation and intelligence tool

### Removed
- Domain-specific schema logic replaced with flexible pattern matching

---

## [1.1.0] — 2026-09-02

### Added
- Streamable HTTP transport replacing SSE transport
- Full OAuth 2.0 flow with dynamic client registration
- `/oauth/authorize`, `/oauth/token`, `/oauth/register` endpoints
- `/.well-known/oauth-authorization-server` discovery endpoint
- CORS configuration for claude.ai browser client
- Bearer token validation on `/mcp` endpoint

### Fixed
- Removed credential guard check that blocked tool execution
- Resolved OAuth registration error when connecting via claude.ai

### Changed
- Transport upgraded from `StdioServerTransport` to `StreamableHTTPServerTransport`
- MCP endpoint changed from SSE `/sse` to Streamable HTTP `/mcp`
- Version bumped to 1.1.0

---

## [1.0.0] — 2026-09-01

### Initial release

- MCP server using `StdioServerTransport` (local only)
- Single tool: `evaluate_current_schema`
  - Validates column structure of spreadsheet data sources
  - Detects Student and Lecturer file schemas
  - Returns column list and connection status
- Deployed to Railway
- Connected to claude.ai via SSE transport

---

*AutoPilot — Plan it. Automate it. Scale it.*
