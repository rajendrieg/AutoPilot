# AutoPilot

**Plan it. Automate it. Scale it.**

AutoPilot is a 34-tool enterprise AI platform delivered as a Model Context Protocol (MCP) server. It connects to Claude via claude.ai or Claude Desktop and gives any organisation the ability to automate workflows, visualise data, forecast trends, model finances, plan growth, and execute goals — entirely through natural language.

---

## What AutoPilot does

| Module | Tools | Capability |
|--------|-------|-----------|
| Automation | 6 | Build, audit, debug, and optimise Power Automate flows |
| Visualisation | 3 | Generate dashboards, graphs, and analytics reports |
| Intelligence | 8 | Forecast trends, predict risks, navigate goals, build plans |
| Finance | 6 | Break-even, ROI, pricing, cash flow, budget, funding gap |
| Scale & Growth | 5 | Scalability assessment, capacity planning, market sizing |
| Communication | 6 | Goal emails, stakeholder reports, escalations, live dashboards |

---

## Quick start

### Prerequisites

- Node.js v18 or higher
- A Railway account (free tier works)
- A Claude.ai account (Pro or Team)
- A GitHub account

### 1. Fork or clone this repository

```bash
git clone https://github.com/rajendrieg/AutoPilot.git
cd AutoPilot
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set environment variables

Copy the example file and fill in your values:

```bash
cp .env.example .env
```

Edit `.env` with your credentials. See `.env.example` for required variables.

### 4. Run locally (optional)

```bash
node AutoPilot.js
```

The server starts on `http://localhost:3000`.

### 5. Deploy to Railway

1. Push your code to GitHub
2. Go to [railway.app](https://railway.app) and sign in with GitHub
3. Click **New Project** → **Deploy from GitHub repo** → select `AutoPilot`
4. Go to **Variables** and add your environment variables from `.env`
5. Go to **Settings → Networking → Generate Domain**
6. Copy your public URL — it will look like `https://autopilot-xxxx.up.railway.app`

### 6. Connect to Claude

1. Open [claude.ai](https://claude.ai) → Settings → Integrations
2. Click **Add Integration**
3. Enter your Railway URL with `/mcp` appended:
   `https://autopilot-xxxx.up.railway.app/mcp`
4. Name it **AutoPilot** and save
5. Toggle AutoPilot **on** in your chat

### 7. Start using AutoPilot

In any Claude chat, try:

```
Use AutoPilot to audit my attendance flow. It runs on a schedule at 4pm 
and sends emails from a SharePoint list.
```

```
Use AutoPilot to generate a Power BI dashboard for my sales data in Excel. 
I want to track revenue, top products, and regional performance.
```

```
Use AutoPilot to calculate my break-even point. Fixed costs are R45,000 
per month, variable cost per unit is R120, and I sell at R350 per unit.
```

---

## All 34 tools

### Module 1 — Automation

| Tool | What it does |
|------|-------------|
| `audit_flow` | Audits a Power Automate flow for errors, gaps, and best practice violations |
| `generate_flow` | Generates a complete flow from a plain English description |
| `debug_flow` | Diagnoses why a flow is failing and returns root causes and fixes |
| `optimize_flow` | Identifies performance issues and returns optimisation recommendations |
| `validate_schema` | Validates column structure of any data source used in a flow |
| `suggest_automation` | Recommends the best automation approach for a manual process |

### Module 2 — Visualisation

| Tool | What it does |
|------|-------------|
| `generate_dashboard` | Generates a complete dashboard spec and build plan |
| `generate_graph` | Recommends the optimal chart type and build instructions |
| `generate_analytics` | Returns statistical insights, patterns, and anomalies |

### Module 3 — Intelligence

| Tool | What it does |
|------|-------------|
| `forecast_trends` | Forecasts future values with confidence intervals |
| `goal_navigator` | Calculates what needs to happen week by week to reach a target |
| `business_plan_navigator` | Generates a complete 5-year business plan framework |
| `research_plan_navigator` | Generates a complete research project plan |
| `trend_intelligence` | Assesses current trend and predicts future trajectory |
| `benchmark_comparator` | Compares your performance against industry benchmarks |
| `risk_predictor` | Predicts which risks will materialise with probability scores |
| `early_warning_system` | Monitors metrics and flags when approaching critical thresholds |

### Module 4 — Finance

| Tool | What it does |
|------|-------------|
| `breakeven_analyser` | Calculates break-even units, revenue, timeline, and sensitivity |
| `roi_calculator` | Computes ROI, payback period, and net present value |
| `pricing_strategy` | Calculates optimal pricing based on cost, margin, and market |
| `budget_allocator` | Distributes a total budget optimally across categories |
| `cash_flow_modeller` | Models cash position month by month with runway calculation |
| `funding_gap_analyser` | Calculates funding gap by phase, timing, and recommended sources |

### Module 5 — Scale & Growth

| Tool | What it does |
|------|-------------|
| `scalability_engine` | Assesses scalability and calculates resource multipliers |
| `capacity_planner` | Plans resources required at each growth stage |
| `growth_modeller` | Models conservative, moderate, and aggressive growth scenarios |
| `unit_economics_calculator` | Shows how unit economics change as you scale |
| `market_sizing_tool` | Estimates TAM, SAM, and realistic revenue potential |

### Module 6 — Communication & Execution

| Tool | What it does |
|------|-------------|
| `goal_communicator` | Generates calibrated progress emails and alerts |
| `stakeholder_reporter` | Generates reports tailored to board, management, team, or funders |
| `intervention_scheduler` | Creates intervention plans with calendar events and owners |
| `milestone_celebrator` | Generates congratulatory communications when targets are hit |
| `escalation_manager` | Escalates critical issues with urgency-calibrated messaging |
| `goal_dashboard_live` | Generates a live goal tracking dashboard with automated refresh |

---

## Architecture

AutoPilot is a Node.js MCP server using:

- `@modelcontextprotocol/sdk` — MCP server framework
- `express` — HTTP server
- Streamable HTTP transport — compatible with claude.ai browser interface
- OAuth 2.0 with dynamic client registration — secure Claude authentication
- Railway — cloud deployment with automatic GitHub sync

```
claude.ai → OAuth → AutoPilot MCP Server (Railway) → Tool handler → Claude response
```

---

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `GITHUB_CLIENT_ID` | Yes | GitHub OAuth app client ID |
| `GITHUB_CLIENT_SECRET` | Yes | GitHub OAuth app client secret |
| `HOST_URL` | Yes | Your Railway public URL |
| `PORT` | No | Server port (Railway sets this automatically) |

---

## Pricing tiers

| Tier | Modules | Tools |
|------|---------|-------|
| Starter | Automation | 6 |
| Professional | Automation + Visualisation | 9 |
| Intelligence | + Intelligence + Finance | 23 |
| Enterprise | All six modules | 34 |

Contact us to discuss pricing: [your contact details]

---

## Roadmap

- [ ] Persistent session management
- [ ] Multi-user token store (Redis)
- [ ] Webhook support for real-time flow triggers
- [ ] Direct Power Automate API integration
- [ ] Power BI REST API integration
- [ ] Usage analytics dashboard
- [ ] Per-tool usage metering for billing

---

## License

Copyright © 2026 AutoPilot. All rights reserved.

See [LICENSE](./LICENSE) for full terms.

---

## Built with

- [Anthropic Claude](https://anthropic.com) — AI reasoning engine
- [Model Context Protocol](https://modelcontextprotocol.io) — tool integration standard
- [Railway](https://railway.app) — cloud deployment
- [Express](https://expressjs.com) — HTTP framework

---

*AutoPilot — Plan it. Automate it. Scale it.*
